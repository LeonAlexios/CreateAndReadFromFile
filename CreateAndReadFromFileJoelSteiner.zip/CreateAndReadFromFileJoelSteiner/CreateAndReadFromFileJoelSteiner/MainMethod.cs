﻿using System;
using System.IO;

namespace CreateAndReadFromFile
{
    public class Program
    {
        static void Main(string[] args)
        {
            string file = "tickets.csv";
            int choice;

            do
            {
                // ask user the question
                Console.WriteLine("1) Read Ticket data from file");
                Console.WriteLine("2) Create Ticket file from data");
                Console.WriteLine("Enter any other key to exit");
                // input the user's response
                choice = Convert.ToInt32(Console.ReadLine());

                if (choice == 1)
                {
                    //read data from file
                    if (File.Exists(file))
                    {
                        ReadFile(file);
                    }

                }
                else if (choice == 2)
                {
                    StreamWriter sw = new StreamWriter(file, true);

                    string ticketIDHeader = "TicketID";
                    string ticketSummaryHeader = "Summary";
                    string ticketStatusHeader = "Status";
                    string ticketPriorityHeader = "Priority";
                    string ticketSubmitterHeader = "Submitter";
                    string ticketAssignedToHeader = "Assigned To";
                    string watchingTicketHeader = "Watching";


                    Console.WriteLine("Enter the Ticket ID: ");
                    int ticketID = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the Ticket Summary: ");
                    string ticketSummary = Console.ReadLine();
                    Console.WriteLine("Enter the Ticket Status: ");
                    string ticketStatus = Console.ReadLine();
                    Console.WriteLine("Enter the Priority of the Ticket: ");
                    string ticketPrioirty = Console.ReadLine();
                    Console.WriteLine("Enter the Submitter of the Ticket: ");
                    string ticketSubmitter = Console.ReadLine();
                    Console.WriteLine("Enter the Employee assigned to the Ticket: ");
                    string ticketAssignedTo = Console.ReadLine();
                    Console.WriteLine("Enter the number of Employees Watching the Ticket: ");
                    int numberOfEmployeesWatching = Convert.ToInt32(Console.ReadLine());

                    List<string> employeesNames = new List<string>();

                    for (int i = 0; i > numberOfEmployeesWatching; i++)
                    {
                        Console.WriteLine("Enter up to 3 names of Employees Watching this Ticket: ");
                        employeesNames[i] = Console.ReadLine();
                        i++;
                    }

                    string watchingTicket = $"{employeesNames[0]}|{employeesNames[1]}|{employeesNames[3]}";



                    sw.WriteLine("{0},{1},{2},{3},{4},{5},{6}", ticketIDHeader, ticketSummaryHeader, ticketStatusHeader, ticketPriorityHeader, ticketSubmitterHeader, ticketAssignedToHeader, watchingTicketHeader);
                    sw.WriteLine("{0},{1},{2},{3},{4},{5},{6}", ticketID, ticketSummary, ticketStatus, ticketPrioirty, ticketSubmitter, ticketAssignedTo, watchingTicket);
                    sw.Close();
                }
            } while (choice == 1 || choice == 2);
        }

        public static string[] ReadFile(string file)
        {
            string[] data = new string[7];
            if (File.Exists(file))
            {
                //Using statement ensures the StreamReader is closed after use
                using (StreamReader sr = new StreamReader(file))
                {
                    sr.ReadLine(); // skips the first line

                    int i = 0;
                    while (!sr.EndOfStream)
                    {
                        var row = sr.ReadLine();
                        var columns = row.Split('|');

                        data[i] = columns[1];
                        Console.WriteLine(data[i]);
                        i++;
                    }
                }
            }
            else
            {
                Console.WriteLine("File does not exist!");
            }
            return data;
        }
    }
}